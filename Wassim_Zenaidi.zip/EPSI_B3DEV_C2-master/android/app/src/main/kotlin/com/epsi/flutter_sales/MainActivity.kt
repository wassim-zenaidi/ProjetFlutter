package com.epsi.flutter_sales

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
