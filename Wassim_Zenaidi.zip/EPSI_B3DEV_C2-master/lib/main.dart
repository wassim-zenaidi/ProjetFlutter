import 'package:flutter/material.dart';
import 'package:flutter_sales/model/cart_model.dart';
import 'package:provider/provider.dart';

import 'page/cart_page.dart';
import 'page/Avis.dart';
import 'page/list_product_page.dart';
import 'page/detail_product_page.dart';

import 'package:go_router/go_router.dart';

import 'page/product_check_page.dart';
import 'model/product_model.dart';

void main() {
  runApp(
      ChangeNotifierProvider<CartModel>(
          create: (_)=>CartModel([]),
          child: MyApp())
  );

}

class MyApp extends StatelessWidget {
  MyApp({super.key});
  final GoRouter _router = GoRouter(
    initialLocation: '/',
    routes: <GoRoute>[
      GoRoute(
        path: '/',
        builder: (_, state) => ListProductPage(),
        //builder: (_, state) => ProductCheckPage(),
        routes: [
          GoRoute(
            path: 'detail',
            builder: (_, state) =>  DetailProductPage(state.extra as Product),
            routes: [
              GoRoute(
                path: 'avis',
                builder: (_, state) =>   AvisPage(state.extra as Product),
              ),
            ]
          ),
          GoRoute(
            path: 'cart',
            builder: (_, state) =>  const CartPage(),
          ),

        ]
      )
    ]
  );


  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      routerConfig: _router,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      //home: CartPage(),
    );
  }
}

