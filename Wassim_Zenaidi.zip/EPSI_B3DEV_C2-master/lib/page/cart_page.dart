import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../model/cart_model.dart';

class CartPage extends StatelessWidget {
  const CartPage({
    Key ? key
  }): super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Panier Flutter Sales"
        ),
        actions: [
          IconButton(
              onPressed: () => context.read < CartModel > ().removeAllProduct(),
              icon: const Icon(
                  Icons.remove_shopping_cart_outlined
              )
          )
        ],
      ),
      body: Column(
        children: [
          Text("Votre panier contient "
              "${context.read<CartModel>().lsProducts.length} "
              "éléments"),

          Text("Votre panier total est de :"+
          "${context.read<CartModel>().getPriceCart()}"
           " eur "),
          Consumer < CartModel > (
              builder: (_, cart, __) => Expanded(
                child: ListView.builder(
                    itemCount: cart.lsProducts.length,
                    itemBuilder: (_, index) =>
                        ListTile(
                          leading: Image.network(cart.lsProducts[index].image,
                             width: 80, height: 80),
                          title: ListTile(title: Text(cart.lsProducts[index].title),) ,
                          trailing: IconButton(
                              onPressed: () => context.read < CartModel > ().removeProduct(cart.lsProducts[index]),
                              icon: const Icon(Icons.remove_shopping_cart_outlined)
                          )
                        ),
                )

                ),

              )


        ],

      ),

    );

  }
}