import 'package:flutter/material.dart';
import 'page/detail_product_page.dart';

import '../model/product_model.dart';

 class AvisPage extends StatelessWidget{
   final Product product;

  const AvisPage(this.product,{Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Les avis du produit"),
        ),

        body:
        Padding(
          padding: const EdgeInsets.all(7.0),
          child : ListTile(
            title: Text("@client :",
                textAlign: TextAlign.start,
                style: Theme.of(context).textTheme.headline6),
          subtitle : Text("Mon avis est que blablabla..."),
            leading: Hero(
              tag: product.image,
              child: Image.network(product.image,
                  width: 80, height: 80),
            ),
          )
        ),


    );
    throw UnimplementedError();
  }

   
}