import 'package:flutter/foundation.dart';
import 'package:flutter_sales/model/product_model.dart';

class CartModel extends ChangeNotifier {
  final List<Product> lsProducts;
  CartModel(this.lsProducts);

  addProduct(Product product){
    lsProducts.add(product);
    notifyListeners();
  }

  removeAllProduct(){
    lsProducts.clear();
    notifyListeners();
  }

  removeProduct(Product p){
    lsProducts.remove(p);
    notifyListeners();
  }

  num getPriceCart(){
    num total = 0;
    lsProducts.forEach((element) {total += element.price;});
    return total.roundToDouble();
  }

}